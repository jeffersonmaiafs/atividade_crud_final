<h1>Exemplo 01</h1>


<ul>
    
    @foreach($categories as $category)
        <li>{{$category->name}}</li>
    @endforeach
    
    
    
</ul>