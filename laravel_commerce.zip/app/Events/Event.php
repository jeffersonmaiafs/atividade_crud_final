<?php

namespace Portfolio\Events;

abstract class Event
{
    //
}
