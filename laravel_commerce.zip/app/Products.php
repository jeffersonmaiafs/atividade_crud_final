<?php

namespace Portfolio;

use Illuminate\Database\Eloquent\Model;

class Products extends Model
{
    //
    protected $fillable = ['name','description','prince"'];
}
